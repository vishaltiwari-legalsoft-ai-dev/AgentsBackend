"use strict";
(() => {
  // src/api.ts
  var STORAGE_KEY = "pairing";
  var NotPaired = class extends Error {
  };
  var Unauthorized = class extends Error {
  };
  function decodePairingCode(code) {
    let decoded;
    try {
      decoded = atob(code.trim());
    } catch {
      throw new Error("That doesn't look like a pairing code \u2014 copy it again from the console.");
    }
    let parsed;
    try {
      parsed = JSON.parse(decoded);
    } catch {
      throw new Error("That pairing code is damaged \u2014 copy it again from the console.");
    }
    if (!parsed.backend_url || !parsed.token) {
      throw new Error("That pairing code is missing the backend URL or token.");
    }
    return {
      backendUrl: parsed.backend_url.replace(/\/+$/, ""),
      token: parsed.token,
      email: parsed.email
    };
  }
  async function savePairing(pairing) {
    await chrome.storage.local.set({ [STORAGE_KEY]: pairing });
  }
  async function loadPairing() {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    return stored[STORAGE_KEY] ?? null;
  }
  async function clearPairing() {
    await chrome.storage.local.remove(STORAGE_KEY);
  }
  async function request(path, init) {
    const pairing = await loadPairing();
    if (!pairing) throw new NotPaired("Paste a pairing code from the AgentOS console to connect.");
    const response = await fetch(`${pairing.backendUrl}/api${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${pairing.token}`,
        ...init?.headers || {}
      }
    });
    if (response.status === 401 || response.status === 403) {
      const detail = await readDetail(response);
      if (response.status === 403 && detail.includes("BROWSER_AGENT_DISABLED")) {
        throw new Error(detail);
      }
      throw new Unauthorized(
        "Your session expired \u2014 copy a fresh pairing code from the AgentOS console."
      );
    }
    if (!response.ok) throw new Error(await readDetail(response));
    return await response.json();
  }
  async function readDetail(response) {
    try {
      const body = await response.json();
      return String(body?.detail || `Request failed (${response.status})`);
    } catch {
      return `Request failed (${response.status})`;
    }
  }
  function status() {
    return request("/browser/status");
  }
  function createRun(goal, mode) {
    return request("/browser/runs", {
      method: "POST",
      body: JSON.stringify({ goal, mode })
    });
  }
  function postStep(runId, body) {
    return request(`/browser/runs/${runId}/step`, {
      method: "POST",
      body: JSON.stringify(body)
    });
  }
  function stopRun(runId) {
    return request(`/browser/runs/${runId}/stop`, { method: "POST" });
  }
  function postDigest(events, tabs) {
    return request("/browser/digest", {
      method: "POST",
      body: JSON.stringify({ events, tabs })
    });
  }

  // src/protocol.ts
  var PROTOCOL = 1;
  var MUTATING_KINDS = /* @__PURE__ */ new Set([
    "navigate",
    "click",
    "type",
    "select",
    "key",
    "open_tab"
  ]);
  function buildStep(input) {
    return {
      protocol: PROTOCOL,
      seq: input.seq,
      tab: input.tab,
      tabs: input.tabs,
      dom: input.dom,
      last_result: input.lastResult ?? null,
      user_reply: input.userReply ?? null,
      confirmed: input.confirmed ?? false,
      screenshot: input.screenshot ?? null
    };
  }
  function hostOf(url) {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return "";
      return parsed.hostname.toLowerCase();
    } catch {
      return "";
    }
  }
  function matches(host, domains) {
    return domains.some((d) => host === d || host.endsWith("." + d));
  }
  function checkUrl(url, allowed, blocked) {
    const host = hostOf(url);
    if (!host) return `refusing to open non-web URL ${url}`;
    if (matches(host, blocked)) return `${host} is on the blocked-domain list`;
    if (allowed.length && !matches(host, allowed)) return `${host} is not on the allow-list`;
    return null;
  }
  function describeAction(action) {
    const why = action.why ? ` \u2014 ${action.why}` : "";
    switch (action.kind) {
      case "navigate":
        return `Opening ${hostOf(action.url || "") || action.url}${why}`;
      case "open_tab":
        return `Opening ${hostOf(action.url || "") || action.url} in a new tab${why}`;
      case "click":
        return `Clicking element ${action.index}${why}`;
      case "type":
        return `Typing into element ${action.index}${why}`;
      case "select":
        return `Choosing "${action.value}"${why}`;
      case "key":
        return `Pressing ${action.text}${why}`;
      case "scroll":
        return `Scrolling ${action.direction || "down"}${why}`;
      case "switch_tab":
        return `Switching to another tab${why}`;
      case "wait":
        return `Waiting for the page${why}`;
      case "extract":
        return `Reading the page${why}`;
      case "ask_user":
        return action.text || "Asking you a question";
      case "done":
        return action.summary || "Finished";
      case "fail":
        return action.reason || "Stopped \u2014 could not finish";
      default:
        return "Unknown step";
    }
  }

  // src/trail.ts
  var MAX_TRAIL = 200;
  function isTrackable(url) {
    return !!hostOf(url) && !url.startsWith("https://chrome.google.com/webstore");
  }
  function appendVisit(trail, visit) {
    if (!isTrackable(visit.url)) return trail;
    const last = trail[trail.length - 1];
    if (last && last.url === visit.url) return trail;
    const entry = {
      url: visit.url.slice(0, 400),
      title: (visit.title || "").slice(0, 120),
      domain: hostOf(visit.url),
      at: visit.at
    };
    const next = [...trail, entry];
    return next.length > MAX_TRAIL ? next.slice(next.length - MAX_TRAIL) : next;
  }

  // src/background.ts
  var STATE_KEY = "runState";
  var TRAIL_KEY = "trail";
  var ALARM = "browser-agent-heartbeat";
  var KEEPALIVE_MS = 2e4;
  var SETTLE_MS = 1200;
  var MAX_TABS = 20;
  var state = null;
  var panel = null;
  var keepalive = null;
  var looping = false;
  chrome.runtime.onInstalled.addListener(() => {
    chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {
    });
  });
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "panel") return;
    panel = port;
    port.onDisconnect.addListener(() => {
      panel = null;
    });
    port.onMessage.addListener((msg) => void handlePanelMessage(msg));
    void restore().then(() => pushStatus());
  });
  function send(type, payload = {}) {
    panel?.postMessage({ type, ...payload });
  }
  function log(text, tone = "step") {
    send("log", { line: { text, tone } });
  }
  function pushStatus(extra = {}) {
    send("status", {
      running: !!state && state.status !== "finished",
      run: state ? { runId: state.runId, goal: state.goal, mode: state.mode, status: state.status } : null,
      ...extra
    });
  }
  async function handlePanelMessage(msg) {
    try {
      switch (msg.cmd) {
        case "hello":
          await restore();
          await reportConnection();
          pushStatus();
          break;
        case "pair": {
          const pairing = decodePairingCode(msg.code || "");
          await savePairing(pairing);
          await reportConnection();
          break;
        }
        case "unpair":
          await clearPairing();
          send("connection", { connected: false, message: "Disconnected." });
          break;
        case "start":
          await startRun(msg.goal || "", msg.mode || "act");
          break;
        case "confirm":
          if (state?.status === "awaiting_confirmation") {
            state.status = "running";
            await persist();
            log("You approved this step.", "ok");
            void loop({ confirmed: true });
          }
          break;
        case "reply":
          if (state?.status === "awaiting_user") {
            state.userReply = msg.reply || "";
            state.status = "running";
            await persist();
            void loop();
          }
          break;
        case "stop":
          await stopRun2("You stopped the run.");
          break;
        case "digest":
          await requestDigest();
          break;
      }
    } catch (err) {
      send("error", { message: errorText(err) });
    }
  }
  function errorText(err) {
    return err instanceof Error ? err.message : String(err);
  }
  async function reportConnection() {
    try {
      const info = await status();
      const mine = chrome.runtime.getManifest().version;
      const latest = info.extension_version || "";
      send("connection", {
        connected: true,
        email: info.email,
        version: mine,
        outdated: !!latest && latest !== mine,
        latest
      });
    } catch (err) {
      send("connection", { connected: false, message: errorText(err) });
    }
  }
  async function persist() {
    await chrome.storage.session.set({ [STATE_KEY]: state });
  }
  async function restore() {
    if (state) return;
    const stored = await chrome.storage.session.get(STATE_KEY);
    state = stored[STATE_KEY] ?? null;
    if (state) state.attached = false;
  }
  async function startRun(goal, mode) {
    if (!goal.trim()) {
      send("error", { message: "Tell me what to do first." });
      return;
    }
    const tab = await activeTab();
    if (!tab?.id) {
      send("error", { message: "Open a normal web page in this window first." });
      return;
    }
    const policy = await createRun(goal.trim(), mode);
    state = {
      runId: policy.run_id,
      goal: goal.trim(),
      mode,
      tabId: tab.id,
      seq: 0,
      stepCap: policy.step_cap,
      allowed: policy.allowed,
      blocked: policy.blocked,
      status: "running",
      attached: false,
      pendingAction: null,
      lastResult: null,
      userReply: null,
      needsScreenshot: false,
      subtask: null
    };
    await persist();
    send("started", { runId: policy.run_id, goal: state.goal, mode });
    log(mode === "monitor" ? "Watching this page (read-only)." : "Working on it.", "ok");
    startHeartbeat();
    void loop();
  }
  async function finish(message, tone) {
    log(message, tone);
    await detach();
    stopHeartbeat();
    if (state) state.status = "finished";
    await persist();
    pushStatus({ finished: true });
    state = null;
    await chrome.storage.session.remove(STATE_KEY);
  }
  async function stopRun2(message) {
    if (!state) return;
    const runId = state.runId;
    await finish(message, "warn");
    try {
      await stopRun(runId);
    } catch (err) {
      send("error", { message: `Stopped locally, but the server wasn't updated: ${errorText(err)}` });
    }
  }
  function startHeartbeat() {
    chrome.alarms.create(ALARM, { periodInMinutes: 0.5 });
    if (keepalive) clearInterval(keepalive);
    keepalive = setInterval(() => void chrome.runtime.getPlatformInfo(), KEEPALIVE_MS);
  }
  function stopHeartbeat() {
    chrome.alarms.clear(ALARM);
    if (keepalive) clearInterval(keepalive);
    keepalive = null;
  }
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name !== ALARM) return;
    await restore();
    if (state && state.status === "running" && !looping) {
      log("Resuming after Chrome paused the extension.", "warn");
      void loop();
    }
  });
  function abandoned(runId) {
    return !state || state.runId !== runId || state.status === "finished";
  }
  async function loop(opts = {}) {
    if (looping) return;
    looping = true;
    const runId = state?.runId ?? "";
    try {
      let confirmed = opts.confirmed ?? false;
      while (state && state.status === "running") {
        const observation = await observe();
        if (abandoned(runId)) return;
        const screenshot = state.needsScreenshot ? await captureViewport() : null;
        if (abandoned(runId)) return;
        if (screenshot) log("Taking a look at the page.", "warn");
        const request2 = buildStep({
          // A confirmation replays the CURRENT seq; everything else advances.
          seq: confirmed ? state.seq : state.seq + 1,
          tab: observation.tab,
          tabs: observation.tabs,
          dom: observation.dom,
          lastResult: state.lastResult,
          userReply: state.userReply,
          confirmed,
          screenshot
        });
        state.needsScreenshot = false;
        state.seq = request2.seq;
        state.userReply = null;
        await persist();
        const response = await postStep(state.runId, request2);
        if (abandoned(runId)) return;
        confirmed = false;
        state.needsScreenshot = !!response.want_screenshot;
        if (response.subtask && response.subtask !== state.subtask) {
          state.subtask = response.subtask;
          const [done, total] = response.subtask_progress ?? [0, 0];
          log(`Step ${Math.min(done + 1, total || 1)} of ${total || 1}: ${response.subtask}`, "ok");
        }
        if (response.done) {
          const done = response.status === "completed";
          await finish(
            done ? response.summary || "Done." : response.fail_reason || `Run ${response.status}.`,
            done ? "ok" : "warn"
          );
          return;
        }
        const action = response.action;
        if (!action) {
          await finish("The server returned no action.", "warn");
          return;
        }
        if (response.requires_confirmation) {
          state.status = "awaiting_confirmation";
          state.pendingAction = action;
          await persist();
          send("confirm", { text: describeAction(action) });
          pushStatus();
          return;
        }
        if (action.kind === "ask_user") {
          state.status = "awaiting_user";
          await persist();
          send("ask", { text: action.text || "" });
          pushStatus();
          return;
        }
        log(describeAction(action), "step");
        const result = await execute(action);
        if (abandoned(runId)) return;
        state.lastResult = result;
        if (!result.ok) log(`Didn't work: ${result.error}`, "warn");
        await persist();
      }
    } catch (err) {
      const message = errorText(err);
      if (err instanceof Unauthorized) {
        send("connection", { connected: false, message });
      }
      await finish(message, "warn");
    } finally {
      looping = false;
    }
  }
  async function activeTab() {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tab;
  }
  function tabInfo(tab) {
    return {
      id: tab.id ?? -1,
      url: tab.url || "",
      title: tab.title || "",
      active: !!tab.active
    };
  }
  async function observe() {
    const all = await chrome.tabs.query({});
    const tabs = all.filter((t) => (t.url || "").startsWith("http")).slice(0, MAX_TABS).map(tabInfo);
    let tab;
    try {
      tab = await chrome.tabs.get(state.tabId);
    } catch {
      tab = await activeTab();
      if (tab?.id) state.tabId = tab.id;
    }
    const dom = tab?.id ? await distillTab(tab.id) : null;
    return { tab: tab ? tabInfo(tab) : null, tabs, dom };
  }
  async function captureViewport() {
    try {
      const tab = await chrome.tabs.get(state.tabId);
      if (tab.windowId === void 0) return null;
      return await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: "jpeg",
        quality: 55
      });
    } catch {
      return null;
    }
  }
  async function distillTab(tabId) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
      const reply = await chrome.tabs.sendMessage(tabId, { cmd: "distill" });
      return reply?.ok ? reply.dom ?? null : null;
    } catch {
      return null;
    }
  }
  async function ensureAttached() {
    if (!state || state.attached) return;
    try {
      await chrome.debugger.attach({ tabId: state.tabId }, "1.3");
      state.attached = true;
    } catch (err) {
      const message = String(err);
      if (message.includes("Another debugger")) {
        throw new Error("Close DevTools on that tab, then press Resume.");
      }
      throw new Error(`Couldn't take control of the tab: ${message}`);
    }
  }
  async function detach() {
    if (!state?.attached) return;
    try {
      await chrome.debugger.detach({ tabId: state.tabId });
    } catch {
    }
    state.attached = false;
  }
  function cdp(method, params) {
    return chrome.debugger.sendCommand({ tabId: state.tabId }, method, params);
  }
  async function clickAt(x, y) {
    const base = { x, y, button: "left", clickCount: 1, buttons: 1 };
    await cdp("Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
    await cdp("Input.dispatchMouseEvent", { ...base, type: "mousePressed" });
    await cdp("Input.dispatchMouseEvent", { ...base, type: "mouseReleased" });
  }
  async function pressKey(key) {
    const codes = {
      enter: { code: "Enter", keyCode: 13, text: "\r" },
      tab: { code: "Tab", keyCode: 9 },
      escape: { code: "Escape", keyCode: 27 },
      backspace: { code: "Backspace", keyCode: 8 }
    };
    const spec = codes[key.trim().toLowerCase()];
    if (!spec) throw new Error(`unsupported key "${key}"`);
    const common = { key: spec.code, code: spec.code, windowsVirtualKeyCode: spec.keyCode };
    await cdp("Input.dispatchKeyEvent", { type: "keyDown", ...common, text: spec.text });
    await cdp("Input.dispatchKeyEvent", { type: "keyUp", ...common });
  }
  async function toContent(cmd) {
    return await chrome.tabs.sendMessage(state.tabId, cmd);
  }
  function settle() {
    return new Promise((resolve) => setTimeout(resolve, SETTLE_MS));
  }
  async function execute(action) {
    const result = { ok: true, action: action.kind, error: null };
    try {
      if (state.mode === "monitor" && MUTATING_KINDS.has(action.kind)) {
        return { ok: false, action: action.kind, error: "monitor mode is read-only" };
      }
      if (action.kind === "navigate" || action.kind === "open_tab") {
        const refusal = checkUrl(action.url || "", state.allowed, state.blocked);
        if (refusal) return { ok: false, action: action.kind, error: refusal };
      }
      switch (action.kind) {
        case "navigate":
          await chrome.tabs.update(state.tabId, { url: action.url });
          await settle();
          break;
        case "open_tab": {
          const tab = await chrome.tabs.create({ url: action.url, active: true });
          if (tab.id) state.tabId = tab.id;
          await settle();
          break;
        }
        case "switch_tab":
          await chrome.tabs.update(action.tab_id, { active: true });
          state.tabId = action.tab_id;
          await detach();
          await settle();
          break;
        case "click": {
          await ensureAttached();
          const focused = await toContent({ cmd: "focus", index: action.index });
          if (!focused.ok) return { ok: false, action: action.kind, error: String(focused.error) };
          const fresh = await toContent({ cmd: "box", index: action.index });
          if (!fresh.box) return { ok: false, action: action.kind, error: "element moved away" };
          const [left, top, width, height] = fresh.box;
          await clickAt(left + width / 2, top + height / 2);
          await settle();
          break;
        }
        case "type": {
          await ensureAttached();
          const focused = await toContent({ cmd: "focus", index: action.index });
          if (!focused.ok) return { ok: false, action: action.kind, error: String(focused.error) };
          await cdp("Input.insertText", { text: action.text || "" });
          const after = await toContent({ cmd: "value", index: action.index });
          if (after.ok && !(after.value || "").includes((action.text || "").trim())) {
            return {
              ok: false,
              action: action.kind,
              error: `the text did not land in element ${action.index} (it reads "${after.value ?? ""}") \u2014 try a different field, or click it first`
            };
          }
          break;
        }
        case "select": {
          const done = await toContent({
            cmd: "select",
            index: action.index,
            value: action.value
          });
          if (!done.ok) return { ok: false, action: action.kind, error: String(done.error) };
          break;
        }
        case "key":
          await ensureAttached();
          await pressKey(action.text || "");
          await settle();
          break;
        case "scroll":
          await toContent({ cmd: "scroll", direction: action.direction || "down" });
          break;
        case "wait":
          await settle();
          break;
        case "extract": {
          const page = await toContent({ cmd: "extract" });
          result.extracted = page.text || "";
          break;
        }
        default:
          return { ok: false, action: action.kind, error: `cannot execute "${action.kind}"` };
      }
      return result;
    } catch (err) {
      return { ok: false, action: action.kind, error: errorText(err) };
    }
  }
  chrome.tabs.onRemoved.addListener(async (tabId) => {
    await restore();
    if (state && state.tabId === tabId && state.status !== "finished") {
      await finish("The tab I was working in was closed.", "warn");
    }
  });
  async function recordVisit(url, title) {
    if (!url) return;
    const stored = await chrome.storage.session.get(TRAIL_KEY);
    const trail = stored[TRAIL_KEY] ?? [];
    const next = appendVisit(trail, { url, title, at: (/* @__PURE__ */ new Date()).toISOString() });
    if (next !== trail) await chrome.storage.session.set({ [TRAIL_KEY]: next });
  }
  chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete") void recordVisit(tab.url, tab.title);
  });
  chrome.tabs.onActivated.addListener(async ({ tabId }) => {
    try {
      const tab = await chrome.tabs.get(tabId);
      await recordVisit(tab.url, tab.title);
    } catch {
    }
  });
  async function requestDigest() {
    send("digestPending", {});
    try {
      const stored = await chrome.storage.session.get(TRAIL_KEY);
      const trail = stored[TRAIL_KEY] ?? [];
      const openTabs = (await chrome.tabs.query({})).filter((t) => (t.url || "").startsWith("http")).map(tabInfo);
      const digest = await postDigest(trail, openTabs);
      send("digest", { digest });
    } catch (err) {
      if (err instanceof Unauthorized) {
        send("connection", { connected: false, message: errorText(err) });
      }
      send("error", { message: errorText(err) });
      send("digestFailed", {});
    }
  }
})();
