"use strict";
(() => {
  // src/sidepanel.ts
  var port = null;
  function connect() {
    const fresh = chrome.runtime.connect({ name: "panel" });
    fresh.onMessage.addListener(handleMessage);
    fresh.onDisconnect.addListener(() => {
      void chrome.runtime.lastError;
      if (port === fresh) port = null;
    });
    port = fresh;
    return fresh;
  }
  function send(message) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        (port ?? connect()).postMessage(message);
        return;
      } catch {
        port = null;
      }
    }
    addLine("Couldn't reach the agent. Close and reopen this panel.", "warn");
  }
  var $ = (id) => document.getElementById(id);
  var conn = $("conn");
  var pairSection = $("pair");
  var codeInput = $("code");
  var goalInput = $("goal");
  var monitorToggle = $("monitor");
  var startBtn = $("startBtn");
  var stopBtn = $("stopBtn");
  var confirmCard = $("confirmCard");
  var confirmText = $("confirmText");
  var askCard = $("askCard");
  var askText = $("askText");
  var askInput = $("askInput");
  var logEl = $("log");
  var digestBtn = $("digestBtn");
  var digestCard = $("digestCard");
  var recordBtn = $("recordBtn");
  var skillCard = $("skillCard");
  var skillText = $("skillText");
  var skillName = $("skillName");
  var recordingNow = false;
  var skillFromRun = true;
  function addLine(text, tone = "step") {
    const div = document.createElement("div");
    div.className = `line ${tone}`;
    div.textContent = text;
    logEl.appendChild(div);
    div.scrollIntoView({ block: "nearest" });
  }
  function setRunning(running) {
    startBtn.disabled = running;
    stopBtn.disabled = !running;
    goalInput.disabled = running;
    monitorToggle.disabled = running;
  }
  function hideCards() {
    confirmCard.classList.add("hidden");
    askCard.classList.add("hidden");
  }
  function renderDigest(d) {
    digestCard.replaceChildren();
    const headline = document.createElement("h2");
    headline.textContent = d.headline;
    digestCard.appendChild(headline);
    const section = (label, items, cls = "") => {
      if (!items.length) return;
      const heading = document.createElement("h3");
      heading.textContent = label;
      const list = document.createElement("ul");
      if (cls) list.className = cls;
      for (const item of items) {
        const li = document.createElement("li");
        li.textContent = item;
        list.appendChild(li);
      }
      digestCard.append(heading, list);
    };
    section("Themes", d.themes.map((t) => `${t.title} \u2014 ${t.detail}`));
    section("Loose ends", d.open_loops);
    section(
      "Watching",
      d.alerts.map((a) => `"${a.rule}" \u2014 ${a.count} page${a.count === 1 ? "" : "s"}`),
      "alert"
    );
    const meta = document.createElement("p");
    meta.className = "meta";
    meta.textContent = `${d.pages_seen} pages visited \xB7 ${d.tabs_open} tabs open now`;
    digestCard.appendChild(meta);
    digestCard.classList.remove("hidden");
  }
  function handleMessage(msg) {
    switch (msg.type) {
      case "connection":
        if (msg.connected) {
          conn.replaceChildren(document.createTextNode("Connected as "));
          const who = document.createElement("b");
          who.textContent = msg.email ?? "your account";
          conn.append(who, document.createTextNode(` \xB7 v${msg.version ?? "?"}`));
          pairSection.classList.add("hidden");
          if (msg.outdated) {
            const warn = document.createElement("p");
            warn.className = "card";
            warn.textContent = `You're running v${msg.version} but v${msg.latest} is available. Download it again from the AgentOS console, replace this folder, then press Reload on chrome://extensions.`;
            conn.after(warn);
          }
        } else {
          conn.textContent = msg.message || "Not connected.";
          pairSection.classList.remove("hidden");
        }
        break;
      case "status":
        setRunning(!!msg.running);
        if (!msg.running) hideCards();
        break;
      case "started":
        logEl.replaceChildren();
        hideCards();
        setRunning(true);
        break;
      case "log":
        addLine(msg.line.text, msg.line.tone);
        break;
      case "confirm":
        confirmText.textContent = `This step needs your OK: ${msg.text}`;
        confirmCard.classList.remove("hidden");
        setRunning(true);
        break;
      case "ask":
        askText.textContent = msg.text;
        askCard.classList.remove("hidden");
        askInput.value = "";
        askInput.focus();
        break;
      case "digestPending":
        digestBtn.disabled = true;
        digestBtn.textContent = "Reading your tabs\u2026";
        break;
      case "digest":
        renderDigest(msg.digest);
        digestBtn.disabled = false;
        digestBtn.textContent = "What's happening in my tabs?";
        break;
      case "digestFailed":
        digestBtn.disabled = false;
        digestBtn.textContent = "What's happening in my tabs?";
        break;
      case "recording":
        recordingNow = !!msg.on;
        recordBtn.textContent = recordingNow ? "Done \u2014 save it" : "Show me how";
        recordBtn.classList.toggle("on", recordingNow);
        if (!recordingNow) {
          skillFromRun = false;
          skillText.textContent = "Saved what you did. What should I call it?";
          skillName.value = "";
          skillCard.classList.remove("hidden");
        }
        break;
      case "offerSkill":
        skillFromRun = true;
        skillText.textContent = "That worked. Want me to remember how, so it's instant next time?";
        skillName.value = String(msg.goal || "").slice(0, 60);
        skillCard.classList.remove("hidden");
        break;
      case "skillSaved":
        skillCard.classList.add("hidden");
        break;
      case "error":
        addLine(msg.message, "warn");
        break;
    }
  }
  digestBtn.addEventListener("click", () => send({ cmd: "digest" }));
  recordBtn.addEventListener("click", () => send({ cmd: "record", on: !recordingNow }));
  $("skillSaveBtn").addEventListener("click", () => {
    send({ cmd: "saveSkill", name: skillName.value, fromRun: skillFromRun });
  });
  $("skillSkipBtn").addEventListener("click", () => {
    skillCard.classList.add("hidden");
    if (recordingNow) send({ cmd: "record", on: false });
  });
  startBtn.addEventListener("click", () => {
    send({
      cmd: "start",
      goal: goalInput.value,
      mode: monitorToggle.checked ? "monitor" : "act"
    });
  });
  stopBtn.addEventListener("click", () => send({ cmd: "stop" }));
  $("pairBtn").addEventListener("click", () => {
    send({ cmd: "pair", code: codeInput.value });
    codeInput.value = "";
  });
  $("confirmBtn").addEventListener("click", () => {
    hideCards();
    send({ cmd: "confirm" });
  });
  $("denyBtn").addEventListener("click", () => {
    hideCards();
    send({ cmd: "stop" });
  });
  $("replyBtn").addEventListener("click", () => {
    hideCards();
    send({ cmd: "reply", reply: askInput.value });
  });
  send({ cmd: "hello" });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") send({ cmd: "hello" });
  });
})();
