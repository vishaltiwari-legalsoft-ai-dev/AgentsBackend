"use strict";
(() => {
  // src/sidepanel.ts
  var port = chrome.runtime.connect({ name: "panel" });
  var $ = (id) => document.getElementById(id);
  var conn = $("conn");
  var pairSection = $("pair");
  var codeInput = $("code");
  var goalInput = $("goal");
  var monitorToggle = $("monitor");
  var startBtn = $("startBtn");
  var stopBtn = $("stopBtn");
  var confirmCard = $("confirmCard");
  var confirmText = $("confirmText");
  var askCard = $("askCard");
  var askText = $("askText");
  var askInput = $("askInput");
  var logEl = $("log");
  var digestBtn = $("digestBtn");
  var digestCard = $("digestCard");
  function addLine(text, tone = "step") {
    const div = document.createElement("div");
    div.className = `line ${tone}`;
    div.textContent = text;
    logEl.appendChild(div);
    div.scrollIntoView({ block: "nearest" });
  }
  function setRunning(running) {
    startBtn.disabled = running;
    stopBtn.disabled = !running;
    goalInput.disabled = running;
    monitorToggle.disabled = running;
  }
  function hideCards() {
    confirmCard.classList.add("hidden");
    askCard.classList.add("hidden");
  }
  function renderDigest(d) {
    digestCard.replaceChildren();
    const headline = document.createElement("h2");
    headline.textContent = d.headline;
    digestCard.appendChild(headline);
    const section = (label, items, cls = "") => {
      if (!items.length) return;
      const heading = document.createElement("h3");
      heading.textContent = label;
      const list = document.createElement("ul");
      if (cls) list.className = cls;
      for (const item of items) {
        const li = document.createElement("li");
        li.textContent = item;
        list.appendChild(li);
      }
      digestCard.append(heading, list);
    };
    section("Themes", d.themes.map((t) => `${t.title} \u2014 ${t.detail}`));
    section("Loose ends", d.open_loops);
    section(
      "Watching",
      d.alerts.map((a) => `"${a.rule}" \u2014 ${a.count} page${a.count === 1 ? "" : "s"}`),
      "alert"
    );
    const meta = document.createElement("p");
    meta.className = "meta";
    meta.textContent = `${d.pages_seen} pages visited \xB7 ${d.tabs_open} tabs open now`;
    digestCard.appendChild(meta);
    digestCard.classList.remove("hidden");
  }
  port.onMessage.addListener((msg) => {
    switch (msg.type) {
      case "connection":
        if (msg.connected) {
          conn.innerHTML = `Connected as <b>${msg.email ?? "your account"}</b>`;
          pairSection.classList.add("hidden");
        } else {
          conn.textContent = msg.message || "Not connected.";
          pairSection.classList.remove("hidden");
        }
        break;
      case "status":
        setRunning(!!msg.running);
        if (!msg.running) hideCards();
        break;
      case "started":
        logEl.replaceChildren();
        hideCards();
        setRunning(true);
        break;
      case "log":
        addLine(msg.line.text, msg.line.tone);
        break;
      case "confirm":
        confirmText.textContent = `This step needs your OK: ${msg.text}`;
        confirmCard.classList.remove("hidden");
        setRunning(true);
        break;
      case "ask":
        askText.textContent = msg.text;
        askCard.classList.remove("hidden");
        askInput.value = "";
        askInput.focus();
        break;
      case "digestPending":
        digestBtn.disabled = true;
        digestBtn.textContent = "Reading your tabs\u2026";
        break;
      case "digest":
        renderDigest(msg.digest);
        digestBtn.disabled = false;
        digestBtn.textContent = "What's happening in my tabs?";
        break;
      case "digestFailed":
        digestBtn.disabled = false;
        digestBtn.textContent = "What's happening in my tabs?";
        break;
      case "error":
        addLine(msg.message, "warn");
        break;
    }
  });
  digestBtn.addEventListener("click", () => port.postMessage({ cmd: "digest" }));
  startBtn.addEventListener("click", () => {
    port.postMessage({
      cmd: "start",
      goal: goalInput.value,
      mode: monitorToggle.checked ? "monitor" : "act"
    });
  });
  stopBtn.addEventListener("click", () => port.postMessage({ cmd: "stop" }));
  $("pairBtn").addEventListener("click", () => {
    port.postMessage({ cmd: "pair", code: codeInput.value });
    codeInput.value = "";
  });
  $("confirmBtn").addEventListener("click", () => {
    hideCards();
    port.postMessage({ cmd: "confirm" });
  });
  $("denyBtn").addEventListener("click", () => {
    hideCards();
    port.postMessage({ cmd: "stop" });
  });
  $("replyBtn").addEventListener("click", () => {
    hideCards();
    port.postMessage({ cmd: "reply", reply: askInput.value });
  });
  port.postMessage({ cmd: "hello" });
})();
