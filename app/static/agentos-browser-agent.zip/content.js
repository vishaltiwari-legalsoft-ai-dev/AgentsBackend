"use strict";
(() => {
  // src/dom.ts
  var INDEX_ATTR = "data-aos-i";
  var MAX_ELEMENTS = 150;
  var MAX_CHARS = 16e3;
  var MAX_TEXT_EXCERPT = 3e3;
  var MAX_LABEL = 80;
  var SELECTOR = [
    "a[href]",
    "button",
    "input",
    "select",
    "textarea",
    "summary",
    "[role=button]",
    "[role=link]",
    "[role=tab]",
    "[role=checkbox]",
    "[role=menuitem]",
    "[role=option]",
    "[contenteditable=true]",
    "[onclick]"
  ].join(",");
  var SECRET_TYPES = /* @__PURE__ */ new Set(["password"]);
  var SECRET_AUTOCOMPLETE = /^(cc-|one-time-code|current-password|new-password)/;
  function isSecretField(el) {
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (SECRET_TYPES.has(type)) return true;
    const autocomplete = (el.getAttribute("autocomplete") || "").toLowerCase();
    if (autocomplete && SECRET_AUTOCOMPLETE.test(autocomplete)) return true;
    const name = `${el.getAttribute("name") || ""} ${el.getAttribute("id") || ""}`.toLowerCase();
    return /password|passwd|cvv|cvc|card.?number|otp/.test(name);
  }
  function boxOf(el) {
    const rect = el.getBoundingClientRect?.();
    if (!rect) return [0, 0, 0, 0];
    return [Math.round(rect.left), Math.round(rect.top), Math.round(rect.width), Math.round(rect.height)];
  }
  function isVisible(el, win) {
    const style = win.getComputedStyle?.(el);
    if (style) {
      if (style.display === "none" || style.visibility === "hidden") return false;
      if (style.opacity !== "" && Number(style.opacity) === 0) return false;
    }
    if (el.hidden) return false;
    if (el.getAttribute("aria-hidden") === "true") return false;
    return true;
  }
  function labelOf(el) {
    const aria = el.getAttribute("aria-label");
    const placeholder = el.getAttribute("placeholder");
    const alt = el.getAttribute("alt");
    const title = el.getAttribute("title");
    const value = el.tagName === "INPUT" && !isSecretField(el) ? el.value : "";
    const text = (el.textContent || "").replace(/\s+/g, " ").trim();
    const label = aria || text || placeholder || value || alt || title || "";
    return label.slice(0, MAX_LABEL);
  }
  function roleOf(el) {
    const role = el.getAttribute("role");
    if (role) return role;
    const tag = el.tagName.toLowerCase();
    if (tag === "input") return (el.getAttribute("type") || "text").toLowerCase();
    return "";
  }
  function rank(el) {
    const [, top] = boxOf(el);
    return top >= 0 ? top : 1e5 + Math.abs(top);
  }
  function distill(doc, win) {
    doc.querySelectorAll(`[${INDEX_ATTR}]`).forEach((el) => el.removeAttribute(INDEX_ATTR));
    const candidates = Array.from(doc.querySelectorAll(SELECTOR)).filter(
      (el) => isVisible(el, win)
    );
    candidates.sort((a, b) => rank(a) - rank(b));
    const elements = [];
    let chars = 0;
    let truncated = candidates.length > MAX_ELEMENTS;
    for (const el of candidates) {
      if (elements.length >= MAX_ELEMENTS) break;
      const i = elements.length;
      const entry = {
        i,
        tag: el.tagName.toLowerCase(),
        box: boxOf(el)
      };
      const role = roleOf(el);
      if (role) entry.role = role;
      const label = isSecretField(el) ? "\u2022\u2022\u2022" : labelOf(el);
      if (label) entry.text = label;
      const href = el.getAttribute("href");
      if (href) entry.href = href.slice(0, 200);
      const size = JSON.stringify(entry).length;
      if (chars + size > MAX_CHARS) {
        truncated = true;
        break;
      }
      chars += size;
      el.setAttribute(INDEX_ATTR, String(i));
      elements.push(entry);
    }
    return {
      elements,
      text_excerpt: pageText(doc).slice(0, MAX_TEXT_EXCERPT),
      truncated
    };
  }
  function pageText(doc) {
    const body = doc.body;
    if (!body) return "";
    const clone = body.cloneNode(true);
    clone.querySelectorAll("script,style,noscript,svg").forEach((n) => n.remove());
    return (clone.textContent || "").replace(/\s+/g, " ").trim();
  }
  function boxForIndex(doc, index) {
    const el = doc.querySelector(`[${INDEX_ATTR}="${index}"]`);
    return el ? boxOf(el) : null;
  }

  // src/content.ts
  var EXTRACT_CHARS = 8e3;
  function elementAt(index) {
    return document.querySelector(`[${INDEX_ATTR}="${index}"]`);
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    try {
      switch (message.cmd) {
        case "distill":
          sendResponse({ ok: true, dom: distill(document, window) });
          break;
        case "box":
          sendResponse({ ok: true, box: boxForIndex(document, message.index) });
          break;
        case "extract":
          sendResponse({ ok: true, text: pageText(document).slice(0, EXTRACT_CHARS) });
          break;
        case "focus": {
          const el = elementAt(message.index);
          if (!el) {
            sendResponse({ ok: false, error: `element ${message.index} is gone` });
            break;
          }
          el.scrollIntoView({ block: "center", behavior: "instant" });
          el.focus?.();
          sendResponse({ ok: true, box: boxForIndex(document, message.index) });
          break;
        }
        case "select": {
          const el = elementAt(message.index);
          if (!el || el.tagName !== "SELECT") {
            sendResponse({ ok: false, error: `element ${message.index} is not a dropdown` });
            break;
          }
          const options = Array.from(el.options);
          const wanted = message.value.toLowerCase();
          const match = options.find((o) => o.value.toLowerCase() === wanted) || options.find((o) => o.text.trim().toLowerCase() === wanted) || options.find((o) => o.text.toLowerCase().includes(wanted));
          if (!match) {
            sendResponse({ ok: false, error: `no option matching "${message.value}"` });
            break;
          }
          el.value = match.value;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          sendResponse({ ok: true });
          break;
        }
        case "scroll":
          window.scrollBy({
            top: message.direction === "up" ? -window.innerHeight * 0.8 : window.innerHeight * 0.8,
            behavior: "instant"
          });
          sendResponse({ ok: true });
          break;
        default:
          sendResponse({ ok: false, error: "unknown command" });
      }
    } catch (err) {
      sendResponse({ ok: false, error: String(err) });
    }
    return true;
  });
})();
