"use strict";
(() => {
  // src/dom.ts
  var INDEX_ATTR = "data-aos-i";
  var MAX_ELEMENTS = 150;
  var MAX_CHARS = 16e3;
  var MAX_TEXT_EXCERPT = 3e3;
  var MAX_LABEL = 80;
  var SELECTOR = [
    "a[href]",
    "button",
    "input",
    "select",
    "textarea",
    "summary",
    "[role=button]",
    "[role=link]",
    "[role=tab]",
    "[role=checkbox]",
    "[role=menuitem]",
    "[role=option]",
    "[contenteditable=true]",
    "[onclick]"
  ].join(",");
  var SECRET_TYPES = /* @__PURE__ */ new Set(["password"]);
  var SECRET_AUTOCOMPLETE = /^(cc-|one-time-code|current-password|new-password)/;
  var MAX_ROOTS = 400;
  function allRoots(doc) {
    const roots = [doc];
    for (let i = 0; i < roots.length && roots.length < MAX_ROOTS; i++) {
      const root = roots[i];
      for (const el of root.querySelectorAll("*")) {
        if (el.shadowRoot) roots.push(el.shadowRoot);
      }
    }
    return roots;
  }
  function queryDeep(doc, selector) {
    const found = [];
    for (const root of allRoots(doc)) found.push(...root.querySelectorAll(selector));
    return found;
  }
  function elementForIndex(doc, index) {
    return queryDeep(doc, `[${INDEX_ATTR}="${index}"]`)[0] ?? null;
  }
  function norm(text) {
    return (text || "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function resolveTarget(doc, target) {
    const wantName = norm(target.name || "");
    const wantRole = norm(target.role || "");
    if (wantName) {
      const matches = queryDeep(doc, `[${INDEX_ATTR}]`).filter((el) => {
        const label = norm(labelOf(el));
        if (!label) return false;
        if (wantRole && norm(roleOf(el) || el.tagName) !== wantRole) return false;
        return label === wantName || label.includes(wantName) || wantName.includes(label);
      });
      if (matches.length === 1) return { ok: true, el: matches[0], by: "name" };
      if (matches.length > 1) {
        const byIndex = matches.find(
          (el) => Number(el.getAttribute(INDEX_ATTR)) === target.index
        );
        if (byIndex) return { ok: true, el: byIndex, by: "name" };
        return {
          ok: false,
          error: `"${target.name}" matches ${matches.length} things on this page`,
          found: matches.map((el) => `${el.tagName.toLowerCase()}: ${labelOf(el)}`).slice(0, 5)
        };
      }
      const at = target.index === void 0 ? null : elementForIndex(doc, target.index);
      return {
        ok: false,
        error: at ? `nothing here is called "${target.name}" \u2014 element ${target.index} is now "${labelOf(at)}"` : `nothing on this page is called "${target.name}"`
      };
    }
    if (target.index !== void 0) {
      const el = elementForIndex(doc, target.index);
      return el ? { ok: true, el, by: "index" } : { ok: false, error: `element ${target.index} is gone` };
    }
    return { ok: false, error: "no element was named" };
  }
  function isSecretField(el) {
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (SECRET_TYPES.has(type)) return true;
    const autocomplete = (el.getAttribute("autocomplete") || "").toLowerCase();
    if (autocomplete && SECRET_AUTOCOMPLETE.test(autocomplete)) return true;
    const name = `${el.getAttribute("name") || ""} ${el.getAttribute("id") || ""}`.toLowerCase();
    return /password|passwd|cvv|cvc|card.?number|otp/.test(name);
  }
  function boxOf(el) {
    const rect = el.getBoundingClientRect?.();
    if (!rect) return [0, 0, 0, 0];
    return [Math.round(rect.left), Math.round(rect.top), Math.round(rect.width), Math.round(rect.height)];
  }
  function hasLayout(doc) {
    return (doc.body?.getBoundingClientRect?.().height ?? 0) > 0;
  }
  function clippedByAncestor(el, win) {
    let node = el.parentElement;
    for (let hops = 0; node && hops < 12; hops++) {
      const style = win.getComputedStyle?.(node);
      const overflow = `${style?.overflow ?? ""}${style?.overflowX ?? ""}${style?.overflowY ?? ""}`;
      if (/hidden|clip|scroll|auto/.test(overflow)) {
        const rect = node.getBoundingClientRect?.();
        if (rect && (rect.width <= 1 || rect.height <= 1)) return true;
      }
      node = node.parentElement ?? (node.getRootNode().host ?? null);
    }
    return false;
  }
  function isVisible(el, win, layout = true) {
    const style = win.getComputedStyle?.(el);
    if (style) {
      if (style.display === "none" || style.visibility === "hidden") return false;
      if (style.opacity !== "" && Number(style.opacity) === 0) return false;
    }
    if (el.hidden) return false;
    if (el.getAttribute("aria-hidden") === "true") return false;
    if (el.hasAttribute("inert")) return false;
    if (!layout) return true;
    const [left, top, width, height] = boxOf(el);
    if (width <= 1 || height <= 1) return false;
    const viewW = win.innerWidth || 0;
    const viewH = win.innerHeight || 0;
    if (left + width <= 0 || top + height <= 0) return false;
    if (viewW && left >= viewW) return false;
    if (viewH && top >= viewH * 3) return false;
    if (clippedByAncestor(el, win)) return false;
    return true;
  }
  function labelOf(el) {
    const aria = el.getAttribute("aria-label");
    const placeholder = el.getAttribute("placeholder");
    const alt = el.getAttribute("alt");
    const title = el.getAttribute("title");
    const value = el.tagName === "INPUT" && !isSecretField(el) ? el.value : "";
    const text = (el.textContent || "").replace(/\s+/g, " ").trim();
    const label = aria || text || placeholder || value || alt || title || "";
    return label.slice(0, MAX_LABEL);
  }
  function roleOf(el) {
    const role = el.getAttribute("role");
    if (role) return role;
    const tag = el.tagName.toLowerCase();
    if (tag === "input") return (el.getAttribute("type") || "text").toLowerCase();
    return "";
  }
  function rank(el) {
    const [, top] = boxOf(el);
    return top >= 0 ? top : 1e5 + Math.abs(top);
  }
  function distill(doc, win) {
    const roots = allRoots(doc);
    for (const root of roots) {
      root.querySelectorAll(`[${INDEX_ATTR}]`).forEach((el) => el.removeAttribute(INDEX_ATTR));
    }
    const layout = hasLayout(doc);
    const candidates = [];
    for (const root of roots) {
      for (const el of root.querySelectorAll(SELECTOR)) {
        if (isVisible(el, win, layout)) candidates.push(el);
      }
    }
    candidates.sort((a, b) => rank(a) - rank(b));
    const elements = [];
    let chars = 0;
    let truncated = candidates.length > MAX_ELEMENTS;
    for (const el of candidates) {
      if (elements.length >= MAX_ELEMENTS) break;
      const i = elements.length;
      const entry = {
        i,
        tag: el.tagName.toLowerCase(),
        box: boxOf(el)
      };
      const role = roleOf(el);
      if (role) entry.role = role;
      const label = isSecretField(el) ? "\u2022\u2022\u2022" : labelOf(el);
      if (label) entry.text = label;
      const href = el.getAttribute("href");
      if (href) entry.href = href.slice(0, 200);
      const size = JSON.stringify(entry).length;
      if (chars + size > MAX_CHARS) {
        truncated = true;
        break;
      }
      chars += size;
      el.setAttribute(INDEX_ATTR, String(i));
      elements.push(entry);
    }
    return {
      elements,
      text_excerpt: pageText(doc).slice(0, MAX_TEXT_EXCERPT),
      truncated,
      canvas_app: isCanvasApp(doc)
    };
  }
  function isCanvasApp(doc) {
    for (const canvas of doc.querySelectorAll("canvas")) {
      const rect = canvas.getBoundingClientRect?.();
      if (rect && rect.width > 400 && rect.height > 300) return true;
    }
    return false;
  }
  function textOf(node) {
    const doc = node.ownerDocument ?? node;
    const holder = doc.createElement("div");
    for (const child of Array.from(node.childNodes)) holder.appendChild(child.cloneNode(true));
    holder.querySelectorAll("script,style,noscript,svg").forEach((n) => n.remove());
    return (holder.textContent || "").replace(/\s+/g, " ").trim();
  }
  function pageText(doc) {
    const body = doc.body;
    if (!body) return "";
    const parts = [textOf(body)];
    for (const root of allRoots(doc)) {
      if (root === doc) continue;
      const text = textOf(root);
      if (text) parts.push(text);
    }
    return [...new Set(parts)].join(" ").replace(/\s+/g, " ").trim();
  }

  // src/recorder.ts
  var MAX_RECORDED = 60;
  function isSecretish(el) {
    const type = (el.getAttribute("type") || "").toLowerCase();
    const auto = (el.getAttribute("autocomplete") || "").toLowerCase();
    const name = `${el.getAttribute("name") || ""}${el.id || ""}`.toLowerCase();
    return type === "password" || /^(cc-|one-time-code|current-password|new-password)/.test(auto) || /pass(word)?|cvv|cvc|otp|secret|token/.test(name);
  }
  function compress(steps) {
    const out = [];
    for (const step of steps) {
      const last = out[out.length - 1];
      if (step.kind === "type" && last?.kind === "type" && last.expect === step.expect) {
        last.text = step.text;
        continue;
      }
      if (step.kind === "type" && last?.kind === "click" && last.expect === step.expect) {
        out[out.length - 1] = step;
        continue;
      }
      if (step.kind === "navigate" && last?.kind === "navigate" && last.url === step.url) {
        continue;
      }
      out.push({ ...step });
      if (out.length >= MAX_RECORDED) break;
    }
    return out;
  }
  function usable(steps) {
    return steps.filter((s) => {
      if (s.kind === "navigate") return !!s.url;
      if (s.kind === "key") return !!s.text;
      return !!s.expect;
    });
  }

  // src/content.ts
  var EXTRACT_CHARS = 8e3;
  function find(target) {
    const found = resolveTarget(document, target || {});
    return found.ok ? { el: found.el } : { error: found.error, found: found.found };
  }
  function labelFor(el) {
    return isSecretField(el) ? "\u2022\u2022\u2022" : labelOf(el);
  }
  var recording = false;
  var recorded = [];
  function namedAncestor(el) {
    for (let node = el, hops = 0; node && hops < 5; hops++) {
      if (labelOf(node)) return node;
      node = node.parentElement;
    }
    return el;
  }
  function note(step) {
    if (!recording || recorded.length >= MAX_RECORDED * 3) return;
    recorded.push(step);
  }
  document.addEventListener(
    "click",
    (event) => {
      if (!recording) return;
      const el = namedAncestor(event.target);
      if (!el) return;
      note({
        kind: "click",
        expect: labelFor(el),
        role: el.tagName.toLowerCase(),
        why: `You clicked "${labelFor(el)}"`
      });
    },
    true
    // capture: the page may stop propagation before we would ever see it
  );
  document.addEventListener(
    "change",
    (event) => {
      if (!recording) return;
      const el = event.target;
      if (!el?.tagName) return;
      if (isSecretish(el)) return;
      const name = labelFor(el);
      if (el.tagName === "SELECT") {
        const select = el;
        note({
          kind: "select",
          expect: name,
          value: select.options[select.selectedIndex]?.text,
          why: `You chose "${select.value}"`
        });
        return;
      }
      note({
        kind: "type",
        expect: name,
        text: el.value ?? "",
        why: `You typed into "${name}"`
      });
    },
    true
  );
  document.addEventListener(
    "keydown",
    (event) => {
      if (!recording) return;
      if (event.key !== "Enter" && event.key !== "Escape") return;
      note({ kind: "key", text: event.key, why: `You pressed ${event.key}` });
    },
    true
  );
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    try {
      switch (message.cmd) {
        case "distill":
          sendResponse({ ok: true, dom: distill(document, window) });
          break;
        case "box": {
          const hit = find(message.target);
          sendResponse("el" in hit ? { ok: true, box: boxOf(hit.el) } : { ok: false, ...hit });
          break;
        }
        case "extract":
          sendResponse({ ok: true, text: pageText(document).slice(0, EXTRACT_CHARS) });
          break;
        case "focus": {
          const hit = find(message.target);
          if (!("el" in hit)) {
            sendResponse({ ok: false, ...hit });
            break;
          }
          const el = hit.el;
          el.scrollIntoView({ block: "center", behavior: "instant" });
          el.focus?.();
          sendResponse({ ok: true, box: boxOf(el), label: labelFor(el) });
          break;
        }
        case "select": {
          const hit = find(message.target);
          if (!("el" in hit)) {
            sendResponse({ ok: false, ...hit });
            break;
          }
          const el = hit.el;
          if (el.tagName !== "SELECT") {
            sendResponse({ ok: false, error: `"${labelFor(el)}" is not a dropdown` });
            break;
          }
          const options = Array.from(el.options);
          const wanted = message.value.toLowerCase();
          const match = options.find((o) => o.value.toLowerCase() === wanted) || options.find((o) => o.text.trim().toLowerCase() === wanted) || options.find((o) => o.text.toLowerCase().includes(wanted));
          if (!match) {
            sendResponse({ ok: false, error: `no option matching "${message.value}"` });
            break;
          }
          el.value = match.value;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          sendResponse({ ok: true });
          break;
        }
        case "value": {
          const hit = find(message.target);
          if (!("el" in hit)) {
            sendResponse({ ok: false, ...hit });
            break;
          }
          const el = hit.el;
          const text = el.isContentEditable ? el.textContent || "" : el.value ?? "";
          sendResponse({ ok: true, value: text });
          break;
        }
        case "record":
          recording = message.on;
          if (message.on) recorded.length = 0;
          sendResponse({ ok: true, recording });
          break;
        case "recorded":
          sendResponse({ ok: true, steps: usable(compress(recorded)) });
          break;
        case "scroll":
          window.scrollBy({
            top: message.direction === "up" ? -window.innerHeight * 0.8 : window.innerHeight * 0.8,
            behavior: "instant"
          });
          sendResponse({ ok: true });
          break;
        default:
          sendResponse({ ok: false, error: "unknown command" });
      }
    } catch (err) {
      sendResponse({ ok: false, error: String(err) });
    }
    return true;
  });
})();
